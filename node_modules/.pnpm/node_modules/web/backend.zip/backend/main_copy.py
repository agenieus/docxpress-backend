from pdf2docx import parse


pdf_file = 'BENEDICT UDEH.pdf'

output_file = 'output_BENEDICT UDEH1.docx'

parse(pdf_file,output_file)

